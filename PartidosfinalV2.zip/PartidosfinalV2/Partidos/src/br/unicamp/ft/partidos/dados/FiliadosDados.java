/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.unicamp.ft.partidos.dados;

import br.unicamp.ft.partidos.modelo.Filiado;
import com.opencsv.CSVReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author c165691
 */
public class FiliadosDados {

    public Map<String,Filiado> lerDados(){
        Map<String,Filiado> listaFiliados = new HashMap();
        try {
            CSVReader reader = new CSVReader(new FileReader("C:\\Users\\c165691.FT\\Desktop\\Partidosfinal\\Partidos\\PSDB.csv"), ';' );
            String[] line;
            while((line = reader.readNext())!= null){
                Filiado filiado = new Filiado();
                filiado.setCodigoInscricao(line[2]);
                filiado.setNome(line[3]);
                filiado.setSituacaoRegistro(line[12]);
                filiado.setMunicipio(line[7]);
               //System.out.println(filiado.getCodigoInscricao() + " " + filiado.getNome()+ " " + filiado.getSituacaoRegistro());
                listaFiliados.put(filiado.getCodigoInscricao(),filiado);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FiliadosDados.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FiliadosDados.class.getName()).log(Level.SEVERE, null, ex);
        }
         
        return listaFiliados;
    }
   
}
