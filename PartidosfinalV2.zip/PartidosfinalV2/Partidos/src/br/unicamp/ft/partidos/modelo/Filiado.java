/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.unicamp.ft.partidos.modelo;

/**
 *
 * @author c165691
 */
public class Filiado {
    private String codigoInscricao;
    private String nome;
    private String situacaoRegistro;
    private String municipio;



    public String getCodigoInscricao() {
        return codigoInscricao;
    }

    public void setCodigoInscricao(String codigoInscricao) {
        this.codigoInscricao = codigoInscricao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getSituacaoRegistro() {
        return situacaoRegistro;
    }

    public void setSituacaoRegistro(String situcaoRegistro) {
        this.situacaoRegistro = situcaoRegistro;
    }
    
    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }
    
    
}
