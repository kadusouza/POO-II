
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author c165691
 */
public class Filiados implements Serializable {
    

    private String data_da_extracao;
    private String hora_da_extracao;
   // private String numero_da_inscricao;
   // private String nome_do_filiado;
   // private String sigla_do_partido;
   // private String nome_do_partido;
    private String uf;
   // private String codigo_do_municipio;
    
    public String getData_da_extracao(){
        return data_da_extracao;
    }
    public void setData_da_extracao(String data_da_extracao){
        this.data_da_extracao = data_da_extracao;
    }
    
    public String getHora_da_extracao(){
        return hora_da_extracao;
    }

    public void setHora_da_extracao(String hora_da_extracao){
        this.hora_da_extracao = hora_da_extracao;
    }
   public String getUf(){
       return uf;
   }
    
   public void setUf(String uf){
       this.uf = uf;
   }

    void add(Filiados filiado) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
