
import com.opencsv.CSVReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Reader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author c165691
 */
public class Politica {
    
    Collection<Filiados> filiado;
 
    /**
     *
     */
    public Politica(){
        filiado = new ArrayList<>();
    }
    
    public void load(URL url) throws IOException {
        Reader source = new InputStreamReader(url.openStream());
        CSVReader reader = new CSVReader(source, ';');
        String[] line;
        while ((line = reader.readNext()) != null) {
            Filiados filiado = new Filiados();
            filiado.setData_da_extracao(line[0]);
            filiado.setHora_da_extracao(line[1]);
        
            
            filiado.add(filiado);
        }
        reader.close();
        source.close();
    }
     public void save(File persist) throws IOException {
        ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(persist) );
        if (filiado != null) {
            output.writeObject(filiado);
        }
    }
    
    public void load(File persist) throws IOException, ClassNotFoundException {
        ObjectInputStream input = new ObjectInputStream(new FileInputStream(persist));
        filiado = (Collection) input.readObject();
    }
    
    @Override
    public String toString() {
        String resposta = "Null";
        if (filiado != null) {
            resposta = "[ ";
            for (Filiados filiado : filiado) {
                resposta = resposta.concat(filiado.getData_da_extracao() + " ");
            }
            resposta = resposta.concat("]");
        }
        return resposta;
    }
}
