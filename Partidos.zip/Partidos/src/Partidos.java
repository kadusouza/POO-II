
import com.opencsv.CSVReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author c165691
 */
public class Partidos {



    public static void main(String[] args) throws FileNotFoundException, IOException {
        
      
       
            CSVReader reader = new CSVReader(new FileReader("C:\\Users\\c165691\\Downloads\\aplic\\sead\\lista_filiados\\uf\\psol.csv"), ';' );
            String[] line;
            while((line = reader.readNext())!= null){
                for(int i = 0;i < line.length; ++i){
                    System.out.print("["+ line[i] + "]");
                }
            System.out.println();
            }
    }
}



    

