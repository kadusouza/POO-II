/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.unicamp.ft.partidos.modelo;

import br.unicamp.ft.partidos.dados.FiliadosDados;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author c165691
 */
public class ListaFiliados {
    Map<String,Filiado> mapaFiliados = new HashMap();
    private final FiliadosDados filiadosDadosPersistencia;
    public ListaFiliados(){
       filiadosDadosPersistencia = new FiliadosDados();
        mapaFiliados = filiadosDadosPersistencia.lerDados();
        
    }
    public static void main(String args[]){
        ListaFiliados listaFiliados = new ListaFiliados();
        System.out.println(listaFiliados.mapaFiliados.size());
    }
    public Map<String,Filiado> buscarFiliado(String nome){
        Map<String,Filiado> filiadosResultado = new TreeMap();
        for(Map.Entry<String,Filiado>filiadoEntry : this.mapaFiliados.entrySet()){
            String nomeFiliado = filiadoEntry.getValue().getNome().toLowerCase();
            if(nomeFiliado.contains(nome)){
                filiadosResultado.put(filiadoEntry.getKey(), filiadoEntry.getValue());
            }
        }
        return filiadosResultado;
    }
}
