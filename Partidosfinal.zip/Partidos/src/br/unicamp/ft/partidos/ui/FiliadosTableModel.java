/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.unicamp.ft.partidos.ui;

import br.unicamp.ft.partidos.modelo.Filiado;
import java.util.Map;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author c165691
 */
public class FiliadosTableModel extends AbstractTableModel {
    
    private final String [] colunas;
    private final String [] listaCodigosFiliados;
    Map<String, Filiado> listaFiliados;
    
    
    public FiliadosTableModel( Map<String, Filiado> listaFiliados){
        colunas = new String[2];
        colunas[0] = "Codigo de Inscrição";
        colunas[1] = "Nome";
        listaCodigosFiliados = listaFiliados.keySet().toArray(new String[listaFiliados.size()]);
        this.listaFiliados = listaFiliados;
    }
    

    @Override
    public int getRowCount() {
        return this.listaCodigosFiliados.length;
    }

    @Override
    public int getColumnCount() {
        return this.colunas.length;
    }
    
    @Override
    public String getColumnName(int num){
        return this.colunas[num];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        String codigo = this.listaCodigosFiliados[rowIndex];
        System.out.println("codigo :" +codigo);
        switch(columnIndex){
            case 0: return this.listaFiliados.get(codigo).getCodigoInscricao();
            case 1: return this.listaFiliados.get(codigo).getNome();
        }
        
        return null;
    }
    
}
